//
// R_SNPRelate.c: Link to the gdsfmt package
//

#include <R_GDS.h>

// do not modify this file, R_GDS2.h is from the gdsfmt package

#include <R_GDS2.h>
